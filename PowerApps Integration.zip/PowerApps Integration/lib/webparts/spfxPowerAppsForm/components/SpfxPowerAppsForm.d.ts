import * as React from "react";
import { ISpfxPowerAppsFormProps } from "./ISpfxPowerAppsFormProps";
export interface ISpfxPowerAppsFormState {
    showModalNew: boolean;
}
export default class SpfxPowerAppsForm extends React.Component<ISpfxPowerAppsFormProps, ISpfxPowerAppsFormState> {
    constructor(props: any);
    render(): React.ReactElement<ISpfxPowerAppsFormProps>;
    private _showModalNew;
    private _closeModalNew;
}
//# sourceMappingURL=SpfxPowerAppsForm.d.ts.map