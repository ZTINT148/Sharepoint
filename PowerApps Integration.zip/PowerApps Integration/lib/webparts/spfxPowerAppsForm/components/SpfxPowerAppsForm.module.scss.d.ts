declare const styles: {
    spfxPowerAppsForm: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
    CloseButton: string;
};
export default styles;
//# sourceMappingURL=SpfxPowerAppsForm.module.scss.d.ts.map