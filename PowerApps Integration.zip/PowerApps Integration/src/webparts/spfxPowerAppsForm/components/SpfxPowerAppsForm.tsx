import * as React from "react";
import styles from "./SpfxPowerAppsForm.module.scss";
import { ISpfxPowerAppsFormProps } from "./ISpfxPowerAppsFormProps";
import { escape } from "@microsoft/sp-lodash-subset";
import { Modal } from "office-ui-fabric-react/lib/Modal";
import Iframe from "react-iframe";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import {
  css,
  classNamesFunction,
  DefaultButton,
  IButtonProps,
  IStyle,
  Label,
  PrimaryButton,
} from "office-ui-fabric-react";

export interface ISpfxPowerAppsFormState {
  showModalNew: boolean;
}

const CloseModal = () => (
  <Icon
    iconName="ChromeClose"
    className="ms-IconExample"
    style={{ fontWeight: "bold" }}
  />
);

export default class SpfxPowerAppsForm extends React.Component<
  ISpfxPowerAppsFormProps,
  ISpfxPowerAppsFormState
> {
  constructor(props: any) {
    super(props);
    this.state = {
      showModalNew: false,
    };
  }

  public render(): React.ReactElement<ISpfxPowerAppsFormProps> {
    return (
      <div>
        <DefaultButton
          id="requestButton"
          onClick={this._showModalNew}
          text="Z-mail"
        ></DefaultButton>
        &nbsp;
        <Modal
          titleAriaId="titleId"
          subtitleAriaId="subtitleId"
          isOpen={this.state.showModalNew}
          onDismiss={this._closeModalNew}
          isBlocking={false}
          containerClassName="ms-modalExample-container"
        >
          <div>
            <span>
              <b>Z-mail</b>{" "}
            </span>
            <DefaultButton
              onClick={this._closeModalNew}
              className={styles.CloseButton}
            >
              <CloseModal />
            </DefaultButton>
          </div>
          <div id="subtitleId" className="ms-modal-body">
            <Iframe
              url={
                "https://apps.powerapps.com/play/90e1ad72-50c4-4fd4-96e0-1dc39915b09f?tenantId=0d50f09d-b59b-4178-9dae-59f9a97fa173&source=portal&screenColor=RGBA(0%2C176%2C240%2C1)"
              }
              width="1024px"
              height="550px"
              position="relative"
              allowFullScreen
            ></Iframe>
          </div>
        </Modal>
      </div>
    );
  }
  private _showModalNew = (): void => {
    this.setState({ showModalNew: true });
  };
  private _closeModalNew = (): void => {
    this.setState({ showModalNew: false });
  };
}
