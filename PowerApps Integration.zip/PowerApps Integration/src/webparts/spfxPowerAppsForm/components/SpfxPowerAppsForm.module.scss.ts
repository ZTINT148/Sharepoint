/* tslint:disable */
require("./SpfxPowerAppsForm.module.css");
const styles = {
  spfxPowerAppsForm: 'spfxPowerAppsForm_59e54a5a',
  teams: 'teams_59e54a5a',
  welcome: 'welcome_59e54a5a',
  welcomeImage: 'welcomeImage_59e54a5a',
  links: 'links_59e54a5a',
  CloseButton: 'CloseButton_59e54a5a'
};

export default styles;
/* tslint:enable */